<?php
    // this is our event id
    // We need to find this event in the database and delete it
    $id = $_POST['id'];

    // but this is a test project so we return true
    return true;
?>